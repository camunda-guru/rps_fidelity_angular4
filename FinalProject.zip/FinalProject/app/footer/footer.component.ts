import {Component} from '@angular/core'
@Component({

    selector:'footer-app',
    templateUrl:'./app/footer/footer.component.html',
    styleUrls:['./app/footer/footer.component.css']
})
export class FooterComponent
{
    private plogo:string;
    constructor()
    {
        this.plogo="./app/images/fidelitylogo.png";
    }

}