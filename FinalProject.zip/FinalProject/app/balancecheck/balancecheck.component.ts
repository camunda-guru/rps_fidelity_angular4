import { Component } from "@angular/core";


@Component({
    selector:"balance-check",
    templateUrl:"./app/balancecheck/balancecheck.component.html",
    styleUrls:["./app/balancecheck/balancecheck.component.css"]
})
export class BalanceAccountComponent
{

    
}