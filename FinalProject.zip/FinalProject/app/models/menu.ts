export class Menu{
    private menuId:number;
    private name:string;

    constructor(id:number,name:string)
    {
        this.menuId=id;
        this.name=name;
    }
    public get MenuId():number
    {
        return this.menuId;
    } 
    public set MenuId(value:number){
        this.menuId=value;
    }
    public get Name():string
    {
        return this.name;
    } 
    public set Name(value:string){
        this.name=value;
    }
     

}