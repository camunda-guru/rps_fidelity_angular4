import { Injectable } from "@angular/core";
import {menuData} from "./menudata"
import {Menu} from "../models/menu";


@Injectable()
export class MenuService
{


    public getmenuData(): Menu[]
    {
        return menuData;
    } 

}