import { Component, OnInit } from "@angular/core";
import { MenuService } from "../services/menuService";


@Component({
    selector:'menu-bar',
    templateUrl:'./app/menu/menu.component.html',
    styleUrls:['./app/menu/menu.component.css']
})
export class MenuComponent implements OnInit
{
    private menuItems:any;

    constructor(public menuSeviceObj:MenuService)
    {

    }
    
    ngOnInit()
    {
      
        this.menuItems=this.menuSeviceObj.getmenuData();


    }


}