import {Menu} from "../models/menu";

export var menuData:Menu[]=[new Menu(1,"New A/C"),
new Menu(2,"Update A/C"),
new Menu(3,"Balance Check")
]