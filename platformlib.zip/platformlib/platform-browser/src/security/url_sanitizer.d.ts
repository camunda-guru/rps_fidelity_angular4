export declare function sanitizeUrl(url: string): string;
export declare function sanitizeSrcset(srcset: string): string;
