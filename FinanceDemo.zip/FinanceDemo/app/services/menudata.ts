import {Menu} from "../models/menu";

export var menuData:Menu[]=[new Menu(1,"Home"),new Menu(2,"New_Account"),
new Menu(3,"Update_Account"),
new Menu(4,"Balance_Check")
]