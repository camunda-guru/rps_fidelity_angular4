import { Component } from "@angular/core";


@Component({
    selector:"update-account",
    templateUrl:"./app/updateaccount/updateaccount.component.html",
    styleUrls:["./app/updateaccount/updateaccount.component.css"]
})
export class UpdateAccountComponent
{

    
}